import React, { useState } from 'react';
import LandingPage from './components/LandingPage';
import DashboardPage from './components/DashboardPage';
import DepositPage from './components/DepositPage';
import AnalyticsPage from './components/AnalyticsPage';
import TransparencyPage from './components/TransparencyPage';
import StartupBlueprint from './components/StartupBlueprint';
import ConnectButton from './components/ConnectButton';
import { Layers, Wallet, BarChart3, ShieldCheck, Rocket, LayoutDashboard } from 'lucide-react';
import { cn } from './lib/utils';

export default function App() {
  const [activeView, setActiveView] = useState<'landing' | 'dashboard' | 'deposit' | 'analytics' | 'transparency' | 'blueprint'>('landing');

  if (activeView === 'landing') {
    return <LandingPage onEnterApp={() => setActiveView('dashboard')} />;
  }

  return (
    <div className="min-h-screen bg-[#020617] selection:bg-blue-500/30 relative overflow-hidden font-sans pb-20">
      <div className="absolute top-[10%] left-[-100px] w-[500px] h-[500px] bg-[#0052FF]/10 rounded-full blur-[120px] pointer-events-none"></div>
      <div className="absolute bottom-[-100px] right-[10%] w-[500px] h-[500px] bg-[#00C2FF]/10 rounded-full blur-[120px] pointer-events-none"></div>

      {/* Top Navigation */}
      <nav className="relative z-10 border-b border-white/10 backdrop-blur-md sticky top-0 bg-[#020617]/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            
            {/* Logo */}
            <div className="flex items-center gap-3 cursor-pointer pt-1" onClick={() => setActiveView('dashboard')}>
              <div className="w-10 h-10 bg-gradient-to-tr from-[#0052FF] to-[#00C2FF] rounded-xl flex items-center justify-center shadow-lg shadow-blue-500/20">
                <Layers className="text-white w-6 h-6" />
              </div>
              <span className="font-display font-bold text-2xl tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-white to-gray-400 mb-0.5 hidden lg:inline-block">
                YieldPilot
              </span>
            </div>

            {/* Navigation Tabs */}
            <div className="flex items-center space-x-1 bg-white/5 p-1 rounded-xl border border-white/10 backdrop-blur-md overflow-x-auto mx-2 hide-scrollbar">
              <button
                onClick={() => setActiveView('dashboard')}
                className={cn(
                  "flex items-center gap-2 px-3 sm:px-4 py-2 rounded-lg text-sm font-semibold transition-all duration-200 whitespace-nowrap",
                  activeView === 'dashboard' 
                    ? "bg-white/10 text-white shadow-sm border border-white/10" 
                    : "text-gray-400 hover:text-white hover:bg-white/5"
                )}
              >
                <LayoutDashboard size={16} />
                <span className="hidden md:inline">Dashboard</span>
              </button>
              <button
                onClick={() => setActiveView('deposit')}
                className={cn(
                  "flex items-center gap-2 px-3 sm:px-4 py-2 rounded-lg text-sm font-semibold transition-all duration-200 whitespace-nowrap",
                  activeView === 'deposit' 
                    ? "bg-white/10 text-white shadow-sm border border-white/10" 
                    : "text-gray-400 hover:text-white hover:bg-white/5"
                )}
              >
                <Wallet size={16} />
                <span className="hidden md:inline">Deposit</span>
              </button>
              <button
                onClick={() => setActiveView('analytics')}
                className={cn(
                  "flex items-center gap-2 px-3 sm:px-4 py-2 rounded-lg text-sm font-semibold transition-all duration-200 whitespace-nowrap",
                  activeView === 'analytics' 
                    ? "bg-white/10 text-white shadow-sm border border-white/10" 
                    : "text-gray-400 hover:text-white hover:bg-white/5"
                )}
              >
                <BarChart3 size={16} />
                <span className="hidden md:inline">Analytics</span>
              </button>
              <button
                onClick={() => setActiveView('transparency')}
                className={cn(
                  "flex items-center gap-2 px-3 sm:px-4 py-2 rounded-lg text-sm font-semibold transition-all duration-200 whitespace-nowrap",
                  activeView === 'transparency' 
                    ? "bg-white/10 text-white shadow-sm border border-white/10" 
                    : "text-gray-400 hover:text-white hover:bg-white/5"
                )}
              >
                <ShieldCheck size={16} />
                <span className="hidden md:inline">Transparency</span>
              </button>
              <button
                onClick={() => setActiveView('blueprint')}
                className={cn(
                  "flex items-center gap-2 px-3 sm:px-4 py-2 rounded-lg text-sm font-semibold transition-all duration-200 whitespace-nowrap",
                  activeView === 'blueprint' 
                    ? "bg-white/10 text-white shadow-sm border border-white/10" 
                    : "text-gray-400 hover:text-white hover:bg-white/5"
                )}
              >
                <Rocket size={16} />
                <span className="hidden md:inline">Roadmap</span>
              </button>
            </div>

            {/* Wallet Connect Placeholder */}
            <div className="shrink-0 flex items-center justify-end">
               <ConnectButton />
            </div>

          </div>
        </div>
      </nav>

      {/* Main Content Area */}
      <main className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 flex-1">
        <div className="animate-in fade-in duration-500 w-full h-full">
          {activeView === 'dashboard' && <DashboardPage onNavigateDeposit={() => setActiveView('deposit')} />}
          {activeView === 'deposit' && <DepositPage />}
          {activeView === 'analytics' && <AnalyticsPage />}
          {activeView === 'transparency' && <TransparencyPage />}
          {activeView === 'blueprint' && <StartupBlueprint />}
        </div>
      </main>

    </div>
  );
}
