export const blueprintData = [
  {
    title: "1. Product Roadmap",
    content: `**30 Days (MVP):** Single Asset Vault (USDC) on Base. Smart contract deployed (ERC-4626 standard). Off-chain AI model running on scheduled cron to optimize between Aave V3 and Compound V3 on Base. Basic frontend interface.\n\n**90 Days (Growth):** Decentralized AI Oracles integration. Add Moonwell & Morpho on Base. Implement risk scoring dashboard for transparency. Zap-in from any asset.\n\n**1 Year (Scale to $1M+ TVL):** Cross-chain auto-compounding. YieldPilot Governance Token (YPLT) launch. Institutional vaults with KYC/AML restrictions.`
  },
  {
    title: "2. MVP App Features",
    content: `**1-Click Deposit/Withdraw:** Seamless UX to deposit USDC from Base network.\n**Live Yield Tracking:** Real-time APY dashboard and total earnings tracker.\n**AI Brain Allocation Feed:** A log showing exactly why the AI moved funds (e.g., \"Moved 40% from Aave to Moonwell due to sudden supply APY spike to 8%.\").\n**Risk Metrics:** Display exact smart contract risk scores and liquidation thresholds.`
  },
  {
    title: "3. Smart Contract Architecture",
    content: `**Vault:** ERC-4626 Tokenized Vault Standard (yield-bearing token: $ypUSDC).\n**Adapters:** Independent routing contracts to interface with specific protocols (Aave, Compound, Moonwell).\n**Rebalancer (Keeper):** Contract that accepts rebalance instructions to move funds between Adapters.\n**Security:** Withdrawals always pull proportional liquidity. Rebalancer can only move funds across whitelisted adapters.`
  },
  {
    title: "4. AI Allocation Engine Logic",
    content: `**Data Ingestion:** Scrape real-time borrow/supply rates, liquidity depth, total TVL, and historical liquidation events every 10 mins.\n**Risk-Adjusted Return Model:** Score each protocol: \`Score = (APY * LiquidityFactor) / RiskWeight.\`\n**Action Thresholds:** Only rebalance if \`(New_APY - Old_APY) > Gas_Cost_To_Rebalance + Slippage_Buffer\`. This prevents thrashing.`
  },
  {
    title: "5. Backend Infrastructure",
    content: `**Serverless Functions:** Node.js/TypeScript backend running hourly cron jobs to feed data to the AI model.\n**AI Model:** Python-based ML model trained on historical DeFi data hosted on Google Cloud.\n**Signer/Relayer:** AWS/GCP KMS for signing rebalance transactions automatically via Gelato or OpenZeppelin Defender.`
  },
  {
    title: "6. Frontend UI/UX Plan",
    content: `**Theme:** Dark, technical, cyber-quant aesthetic. Professional minimalism.\n**Dashboard:** At-a-glance portfolio value, large APY numbers, historical chart.\n**Status Feed:** \"AI Thinking...\" ticker showing market scans to build trust.`
  },
  {
    title: "7. Revenue Model",
    content: `**Performance Fee:** 10-15% of *yield generated* (standard DeFi hedge fund model). No management fee. If we don't make you money, we don't get paid.\n**Withdrawal Fee:** 0.1% early withdrawal fee (to prevent flash-churning), waived after 7 days.`
  },
  {
    title: "8. Tokenomics (Later Stage)",
    content: `**Utility:** Staking for fee discounts, boosting yield percentages.\n**Governance:** Voting on whitelisted protocols and new chain expansions.\n**Emissions:** Deflationary. Use portion of protocol revenue to buyback and burn $YPLT on Base DEXes.`
  },
  {
    title: "9. Security Checklist",
    content: `- [ ] Contract Code: No upgradeable proxies initially (immutable).\n- [ ] Security Audit: Solo audit (e.g., Code4rena).\n- [ ] Multisig: 3-of-4 Gnosis Safe on Base for contract ownership.\n- [ ] Pausability: Emergency pause switch triggered by anomaly detection.\n- [ ] Limits: Max drawdowns limit hardcoded.`
  },
  {
    title: "10. Marketing Strategy",
    content: `**Twitter/X Alpha:** Build in public. Share raw data of AI outperforming manual yield farming. Tag Base & Brian Armstrong.\n**Warpcast/Farcaster:** Highly active Base chain audience. Launch exclusive early-access Frame.\n**Incentivized Beta:** First 100 users get a \"Pioneer\" NFT that guarantees 0% performance fees for 3 months.`
  },
  {
    title: "11. Exact Tech Stack",
    content: `**Frontend:** React, Vite, TailwindCSS, Viem/Wagmi, Recharts.\n**Backend:** Node.js, serverless, Supabase.\n**AI/Quant:** Python, Jupyter, Google Gemini API for risk summaries, scikit-learn.\n**Smart Contracts:** Foundry, Solidity 0.8.24, Base RPC.`
  },
  {
    title: "12. Daily Execution Plan",
    content: `**Morning (Deep Work):** Smart contract writing / AI model tuning (3 hrs).\n**Mid-day (Building/Commits):** Frontend UI, Web3 integration, backend server setup (3 hrs).\n**Afternoon (Marketing):** Post \"Build in Public\" threads on X and Warpcast (1 hr).\n**Evening (Review):** Testnet deployments, security checks, code review (1 hr).`
  }
];
