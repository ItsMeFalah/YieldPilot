export const vaultContractCode = `// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {ERC4626} from "@openzeppelin/contracts/token/ERC20/extensions/ERC4626.sol";
import {ERC20} from "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {AccessControl} from "@openzeppelin/contracts/access/AccessControl.sol";
import {Pausable} from "@openzeppelin/contracts/utils/Pausable.sol";

/**
 * @title YieldPilotVault
 * @notice AI-managed USDC auto-compounding vault on Base.
 * @dev Implements ERC-4626 Tokenized Vault Standard.
 */
contract YieldPilotVault is ERC4626, AccessControl, Pausable {
    using SafeERC20 for IERC20;

    bytes32 public constant AI_KEEPER_ROLE = keccak256("AI_KEEPER_ROLE");
    bytes32 public constant EMERGENCY_ADMIN_ROLE = keccak256("EMERGENCY_ADMIN_ROLE");

    uint256 public performanceFeeBps; // e.g., 1000 = 10%
    address public treasury;
    
    uint256 private highWaterMark;
    address[] public whitelistedAdapters;

    event YieldHarvested(uint256 totalProfit, uint256 feeShares);
    event Rebalanced(address indexed toStrategy, uint256 amount);

    constructor(
        IERC20 _asset,
        address _initialAdmin,
        address _aiKeeper,
        address _treasury
    ) ERC4626(_asset) ERC20("YieldPilot USDC", "ypUSDC") {
        _grantRole(DEFAULT_ADMIN_ROLE, _initialAdmin);
        _grantRole(EMERGENCY_ADMIN_ROLE, _initialAdmin);
        _grantRole(AI_KEEPER_ROLE, _aiKeeper);
        
        treasury = _treasury;
        performanceFeeBps = 1000; // 10%
    }

    // --- PAUSE MECHANISM ---
    /**
     * @notice Emergency shutdown. Halts deposits and rebalances.
     * @dev Withdrawals are left unlocked intentionally to protect user funds.
     */
    function pause() external onlyRole(EMERGENCY_ADMIN_ROLE) {
        _pause();
    }

    function unpause() external onlyRole(DEFAULT_ADMIN_ROLE) {
        _unpause();
    }

    // --- ERC-4626 OVERRIDES ---
    function deposit(uint256 assets, address receiver) public override whenNotPaused returns (uint256) {
        return super.deposit(assets, receiver);
    }

    function mint(uint256 shares, address receiver) public override whenNotPaused returns (uint256) {
        return super.mint(shares, receiver);
    }

    // --- AI KEEPER LOGIC ---
    /**
     * @notice AI Relayer calls this to move funds to a whitelisted strategy
     */
    function rebalance(address strategyAdapter, uint256 amount) external onlyRole(AI_KEEPER_ROLE) whenNotPaused {
        // Transfer USDC to strategy adapter
        // Expected that strategy adapter deposits into Aave/Moonwell on Base
        IERC20(asset()).safeTransfer(strategyAdapter, amount);
        emit Rebalanced(strategyAdapter, amount);
    }

    /**
     * @notice Harvests yield and computes performance fee via High-Water Mark
     */
    function harvest() external onlyRole(AI_KEEPER_ROLE) {
        uint256 currentAssets = totalAssets();
        
        // Only take fees if we are actually in profit above the historical max
        if (currentAssets > highWaterMark) {
            uint256 profit = currentAssets - highWaterMark;
            uint256 feeAmount = (profit * performanceFeeBps) / 10000;
            
            // Mint shares equivalent to fee directly to Treasury
            uint256 feeShares = previewDeposit(feeAmount);
            _mint(treasury, feeShares);
            
            highWaterMark = totalAssets(); // Update watermark
            emit YieldHarvested(profit, feeShares);
        }
    }

    /**
     * @notice Override to include assets deployed across all strategies
     */
    function totalAssets() public view override returns (uint256) {
        uint256 total = IERC20(asset()).balanceOf(address(this));
        
        // Loop through strategy adapters to get deployed balances
        for (uint i = 0; i < whitelistedAdapters.length; i++) {
            // total += IStrategyAdapter(whitelistedAdapters[i]).totalAssets();
        }
        
        return total;
    }
}`;
