import { parseAbi } from 'viem';

// TODO: Deploy your YieldPilotVault.sol to Base and update this address!
export const VAULT_ADDRESS = '0x2C5bb4BF97BCdeF02EcD3b89a7E428164A9D2fcb'; 
// Base Mainnet Native USDC
export const USDC_ADDRESS = '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913'; 

export const vaultAbi = parseAbi([
  'function deposit(uint256 assets, address receiver) returns (uint256 shares)',
  'function withdraw(uint256 assets, address receiver, address owner) returns (uint256 shares)',
  'function balanceOf(address account) view returns (uint256)',
  'function totalAssets() view returns (uint256)',
  'function decimals() view returns (uint8)',
  'function name() view returns (string)',
  'function symbol() view returns (string)',
  'function convertToAssets(uint256 shares) view returns (uint256)',
  'function convertToShares(uint256 assets) view returns (uint256)',
  'function hasRole(bytes32 role, address account) view returns (bool)',
  'function AI_KEEPER_ROLE() view returns (bytes32)',
  'function rebalance(address strategyAdapter, uint256 amount)',
  'function harvest()',
]);

export const erc20Abi = parseAbi([
  'function approve(address spender, uint256 amount) returns (bool)',
  'function allowance(address owner, address spender) view returns (uint256)',
  'function balanceOf(address account) view returns (uint256)',
  'function decimals() view returns (uint8)',
  'function symbol() view returns (string)',
]);
