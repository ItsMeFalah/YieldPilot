import React, { createContext, useContext, useState, ReactNode } from 'react';

interface Transaction {
  id: string;
  type: 'deposit' | 'withdraw';
  amount: number;
  date: Date;
  status: 'completed';
  txHash: string;
}

interface VaultState {
  depositedBalance: number;
  earnedYield: number;
  history: Transaction[];
  deposit: (amount: number, txHash?: string) => void;
  withdraw: (amount: number, txHash?: string) => void;
}

const VaultContext = createContext<VaultState | undefined>(undefined);

export function VaultProvider({ children }: { children: ReactNode }) {
  const [depositedBalance, setDepositedBalance] = useState(0);
  const [earnedYield, setEarnedYield] = useState(0); // Mock yield
  const [history, setHistory] = useState<Transaction[]>([]);

  const deposit = (amount: number, txHash: string = `0x${Math.random().toString(16).slice(2)}...`) => {
    setDepositedBalance(prev => prev + amount);
    setHistory(prev => [{
      id: Math.random().toString(36).substr(2, 9),
      type: 'deposit',
      amount,
      date: new Date(),
      status: 'completed',
      txHash
    }, ...prev]);
  };

  const withdraw = (amount: number, txHash: string = `0x${Math.random().toString(16).slice(2)}...`) => {
    if (depositedBalance >= amount) {
      setDepositedBalance(prev => prev - amount);
      setHistory(prev => [{
        id: Math.random().toString(36).substr(2, 9),
        type: 'withdraw',
        amount,
        date: new Date(),
        status: 'completed',
        txHash
      }, ...prev]);
    }
  };

  // Simulate a little bit of yield being earned every 10 seconds if there's a balance
  React.useEffect(() => {
    if (depositedBalance === 0) return;
    const interval = setInterval(() => {
      setEarnedYield(prev => prev + (depositedBalance * 0.0000001)); // Mock APY trickle
    }, 5000);
    return () => clearInterval(interval);
  }, [depositedBalance]);

  return (
    <VaultContext.Provider value={{ depositedBalance, earnedYield, history, deposit, withdraw }}>
      {children}
    </VaultContext.Provider>
  );
}

export function useVault() {
  const context = useContext(VaultContext);
  if (context === undefined) {
    throw new Error('useVault must be used within a VaultProvider');
  }
  return context;
}
