import {
  Web3Function,
  Web3FunctionContext,
} from "@gelatonetwork/web3-functions-sdk";
import { Contract, utils } from "ethers";

const VAULT_ADDRESS = "0x2C5bb4BF97BCdeF02EcD3b89a7E428164A9D2fcb";
const VAULT_ABI = [
  "function rebalance(address strategyAdapter, uint256 amount)",
  "function harvest()",
  "function totalAssets() view returns (uint256)"
];

// Mock Strategy Registry on Base
const STRATEGIES = [
  { name: "Aerodrome V2 (USDC)", address: "0x...", apy: 14.2, tvl: 124000000, scr: 8, vol: 0.15 },
  { name: "Moonwell (USDC)", address: "0x...", apy: 8.4, tvl: 68000000, scr: 9, vol: 0.05 },
];

/**
 * Gelato Web3 Function
 * This runs entirely on Gelato's decentralized nodes (no server needed).
 */
Web3Function.onRun(async (context: Web3FunctionContext) => {
  const { multiChainProvider, storage } = context;
  const provider = multiChainProvider.default();
  
  // 1. Calculate highest utility strategy off-chain
  let bestStrategy = STRATEGIES[0];
  let maxUtility = -999;

  for (const s of STRATEGIES) {
    const norm_apy = s.apy / 20.0;
    const norm_tvl = Math.min(s.tvl / 100000000, 1.0);
    const norm_scr = s.scr / 10.0;
    const norm_vol = Math.max(0, 1.0 - s.vol);

    const utility = (0.40 * norm_apy) + (0.20 * norm_tvl) - (0.25 * (1 - norm_scr)) - (0.15 * (1 - norm_vol));
    
    if (utility > maxUtility) {
      maxUtility = utility;
      bestStrategy = s;
    }
  }

  // 2. Fetch on-chain state to see if it's worth rebalancing
  const vault = new Contract(VAULT_ADDRESS, VAULT_ABI, provider);
  const totalAssets = await vault.totalAssets();
  
  // (Simplified checks omitted for brevity)
  // Calculate if the yield delta surpasses the gas cost
  const gasPrice = await provider.getGasPrice();
  
  const estimatedGasUsd = Number(utils.formatEther(gasPrice)) * 100000 * 3000; // Base gas * gasLimit * ETH price
  const expectedYieldIncrease = (Number(utils.formatUnits(totalAssets, 6)) * 0.05); // 5% boost

  // 3. Trigger condition
  if (expectedYieldIncrease > estimatedGasUsd * 3) {
    console.log(`Action Required! Routing cash into ${bestStrategy.name}`);
    
    return {
      canExec: true,
      callData: [
        {
          to: VAULT_ADDRESS,
          data: vault.interface.encodeFunctionData("rebalance", [
            bestStrategy.address, 
            totalAssets // moving all funds into the optimal strategy for the example
          ]),
        },
      ],
    };
  }

  return { canExec: false, message: "Yield delta does not overcome gas threshold. Idling." };
});
