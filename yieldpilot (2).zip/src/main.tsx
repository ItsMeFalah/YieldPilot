import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { Web3Provider } from './components/Web3Provider';
import { VaultProvider } from './lib/VaultContext';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <Web3Provider>
      <VaultProvider>
        <App />
      </VaultProvider>
    </Web3Provider>
  </StrictMode>,
);
