// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {ERC4626} from "@openzeppelin/contracts/token/ERC20/extensions/ERC4626.sol";
import {ERC20} from "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {AccessControl} from "@openzeppelin/contracts/access/AccessControl.sol";
import {Pausable} from "@openzeppelin/contracts/utils/Pausable.sol";

/**
 * @title YieldPilotVault
 * @notice AI-managed USDC auto-compounding vault on Base.
 * @dev Implements ERC-4626 Tokenized Vault Standard.
 */
contract YieldPilotVault is ERC4626, AccessControl, Pausable {
    using SafeERC20 for IERC20;

    bytes32 public constant AI_KEEPER_ROLE = keccak256("AI_KEEPER_ROLE");
    bytes32 public constant EMERGENCY_ADMIN_ROLE = keccak256("EMERGENCY_ADMIN_ROLE");

    uint256 public performanceFeeBps; // e.g., 1000 = 10%
    address public treasury;
    
    uint256 private highWaterMark;
    address[] public whitelistedAdapters;

    event YieldHarvested(uint256 totalProfit, uint256 feeShares);
    event Rebalanced(address indexed toStrategy, uint256 amount);

    constructor(
        IERC20 _asset,
        address _initialAdmin,
        address _aiKeeper,
        address _treasury
    ) ERC4626(_asset) ERC20("YieldPilot USDC", "ypUSDC") {
        _grantRole(DEFAULT_ADMIN_ROLE, _initialAdmin);
        _grantRole(EMERGENCY_ADMIN_ROLE, _initialAdmin);
        _grantRole(AI_KEEPER_ROLE, _aiKeeper);
        
        treasury = _treasury;
        performanceFeeBps = 1000; // 10%
    }

    // --- PAUSE MECHANISM ---
    function pause() external onlyRole(EMERGENCY_ADMIN_ROLE) {
        _pause();
    }

    function unpause() external onlyRole(DEFAULT_ADMIN_ROLE) {
        _unpause();
    }

    // --- ERC-4626 OVERRIDES ---
    function deposit(uint256 assets, address receiver) public override whenNotPaused returns (uint256) {
        return super.deposit(assets, receiver);
    }

    function mint(uint256 shares, address receiver) public override whenNotPaused returns (uint256) {
        return super.mint(shares, receiver);
    }

    // --- AI KEEPER LOGIC ---
    function rebalance(address strategyAdapter, uint256 amount) external onlyRole(AI_KEEPER_ROLE) whenNotPaused {
        IERC20(asset()).safeTransfer(strategyAdapter, amount);
        emit Rebalanced(strategyAdapter, amount);
    }

    function harvest() external onlyRole(AI_KEEPER_ROLE) {
        uint256 currentAssets = totalAssets();
        
        if (currentAssets > highWaterMark) {
            uint256 profit = currentAssets - highWaterMark;
            uint256 feeAmount = (profit * performanceFeeBps) / 10000;
            
            uint256 feeShares = previewDeposit(feeAmount);
            _mint(treasury, feeShares);
            
            highWaterMark = totalAssets();
            emit YieldHarvested(profit, feeShares);
        }
    }

    function totalAssets() public view override returns (uint256) {
        uint256 total = IERC20(asset()).balanceOf(address(this));
        
        for (uint i = 0; i < whitelistedAdapters.length; i++) {
            // total += IStrategyAdapter(whitelistedAdapters[i]).totalAssets();
        }
        
        return total;
    }
}
