import React from "react";
import { blueprintData } from "../lib/blueprintData";

export default function StartupBlueprint() {
  return (
    <div className="max-w-4xl mx-auto space-y-12 pb-24">
      
      <div className="space-y-4">
        <h1 className="font-display text-4xl sm:text-5xl font-bold tracking-tight text-white">
          YieldPilot <span className="text-blue-500">Blueprint</span>
        </h1>
        <p className="text-xl text-gray-400 font-sans">
          AI Liquidity Manager on Base Chain. Maximizing yield, minimizing risk, fully transparent.
        </p>
        <div className="flex flex-wrap gap-3 mt-4">
          <span className="px-3 py-1 bg-blue-500/10 text-blue-400 border border-blue-500/20 rounded-full text-xs font-mono uppercase tracking-wider">Target: $1M+ TVL</span>
          <span className="px-3 py-1 bg-blue-500/10 text-blue-400 border border-blue-500/20 rounded-full text-xs font-mono uppercase tracking-wider">Asset: USDC</span>
          <span className="px-3 py-1 bg-blue-500/10 text-blue-400 border border-blue-500/20 rounded-full text-xs font-mono uppercase tracking-wider">Chain: Base</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {blueprintData.map((section, idx) => (
          <div 
            key={idx} 
            className="group relative bg-white/5 border border-white/10 backdrop-blur-xl p-6 rounded-3xl hover:border-[#0052FF]/50 hover:bg-white/10 transition-colors duration-300"
          >
            <div className="absolute top-0 left-6 -translate-y-1/2 bg-[#020617] px-2 rounded-sm">
               <span className="text-blue-400 font-mono text-sm font-bold tracking-wider">{section.title.split('.')[0].padStart(2, '0')}</span>
            </div>
            
            <h3 className="text-lg font-semibold text-white mb-4 mt-2 font-display">
              {section.title.split('. ')[1]}
            </h3>
            
            <div className="space-y-3 text-sm text-gray-400 leading-relaxed font-sans">
                {section.content.split('\\n\\n').map((paragraph, pIdx) => {
                  return (
                    <p key={pIdx}>
                        {/* A very basic markdown-lite renderer for bold text */}
                        {paragraph.split(/(\*\*.*?\*\*)/).map((part, i) => {
                          if (part.startsWith('**') && part.endsWith('**')) {
                            return <strong key={i} className="text-gray-200 font-semibold">{part.slice(2, -2)}</strong>;
                          }
                          // Handle inline code \`code\`
                          if (part.includes('\`')) {
                             return part.split(/(\`.*?\`)/).map((subPart, j) => {
                               if (subPart.startsWith('\`') && subPart.endsWith('\`')) {
                                 return <code key={j} className="text-blue-300 bg-blue-900/20 px-1 py-0.5 rounded text-xs font-mono">{subPart.slice(1, -1)}</code>;
                               }
                               return <span key={j}>{subPart}</span>;
                             });
                          }
                          return <span key={i}>{part}</span>;
                        })}
                    </p>
                  );
                })}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
