import React, { useState } from 'react';
import { BrainCircuit, Activity, ShieldAlert, BarChart3, Minimize2, Network, RefreshCw, Database, Bot, Zap, ExternalLink } from 'lucide-react';
import { cn } from '../lib/utils';
import { useAccount, useReadContract, useWriteContract, useWaitForTransactionReceipt, useSwitchChain } from 'wagmi';
import { base } from 'wagmi/chains';
import { vaultAbi, VAULT_ADDRESS } from '../lib/contracts';
import { parseUnits } from 'viem';

export default function AIEngine() {
  const { address, isConnected, chainId } = useAccount();
  const { switchChain } = useSwitchChain();
  const isWrongNetwork = isConnected && chainId !== base.id;

  const { data: aiKeeperRole } = useReadContract({
    address: VAULT_ADDRESS as `0x${string}`,
    abi: vaultAbi,
    functionName: 'AI_KEEPER_ROLE',
  });

  const { data: isKeeper } = useReadContract({
    address: VAULT_ADDRESS as `0x${string}`,
    abi: vaultAbi,
    functionName: 'hasRole',
    args: address && aiKeeperRole ? [aiKeeperRole as `0x${string}`, address] : undefined,
    query: {
      enabled: !!address && !!aiKeeperRole,
    }
  });

  const { writeContract: writeHarvest, data: harvestHash, isPending: isHarvestingTx } = useWriteContract();
  const { writeContract: writeRebalance, data: rebalanceHash, isPending: isRebalancingTx } = useWriteContract();

  const { isLoading: isWaitingHarvest, isSuccess: isHarvestSuccess } = useWaitForTransactionReceipt({ hash: harvestHash });
  const { isLoading: isWaitingRebalance, isSuccess: isRebalanceSuccess } = useWaitForTransactionReceipt({ hash: rebalanceHash });

  const [strategyAddress, setStrategyAddress] = useState('');
  const [rebalanceAmount, setRebalanceAmount] = useState('');

  const handleHarvest = () => {
    if (isWrongNetwork) { switchChain({ chainId: base.id }); return; }
    writeHarvest({
      address: VAULT_ADDRESS as `0x${string}`,
      abi: vaultAbi,
      functionName: 'harvest',
    });
  };

  const handleRebalance = () => {
    if (isWrongNetwork) { switchChain({ chainId: base.id }); return; }
    if (!strategyAddress || !rebalanceAmount) return;
    writeRebalance({
      address: VAULT_ADDRESS as `0x${string}`,
      abi: vaultAbi,
      functionName: 'rebalance',
      args: [strategyAddress as `0x${string}`, parseUnits(rebalanceAmount, 6)],
    });
  };
  return (
    <div className="max-w-7xl mx-auto space-y-6 pb-24">
      
      {/* Header section */}
      <div className="space-y-4 mb-8">
        <h1 className="font-display text-3xl sm:text-4xl font-bold tracking-tight text-white flex items-center gap-3">
          <BrainCircuit className="text-purple-500" size={32} />
          Quant Allocation <span className="bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-[#00C2FF]">Engine</span>
        </h1>
        <p className="text-gray-400 font-sans leading-relaxed max-w-3xl">
          The core machine learning model orchestrating capital across Base's DeFi ecosystem. It calculates a risk-adjusted utility score for every whitelist pool before executing cross-protocol rebalances.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Core Mathematical Model */}
        <div className="lg:col-span-12 bg-white/5 border border-white/10 backdrop-blur-xl rounded-3xl p-6 relative overflow-hidden">
           <div className="absolute top-0 right-0 w-64 h-64 bg-purple-500/10 blur-[80px] rounded-full pointer-events-none"></div>
           <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-2 font-display">
             <BarChart3 className="text-purple-400" size={20} /> The Scoring Model
           </h3>
           
           <div className="flex flex-col md:flex-row gap-8 items-center bg-[#020617]/50 rounded-2xl p-6 border border-white/5">
              <div className="flex-1 space-y-2">
                 <p className="text-sm text-gray-400">Utility Score (U) equation applied to Strategy (i):</p>
                 <div className="font-mono text-lg md:text-xl text-white font-medium tracking-wide">
                    U<sub className="text-xs">i</sub> = &alpha;&times;<span className="text-green-400">APY</span> + &beta;&times;<span className="text-blue-400">TVL_Depth</span> - &gamma;&times;<span className="text-red-400">SC_Risk</span> - &delta;&times;<span className="text-yellow-400">Vol</span>
                 </div>
              </div>
              <div className="hidden md:block w-px h-16 bg-white/10"></div>
              <div className="flex-1 text-sm text-gray-400 space-y-2">
                 <p>Every 10 minutes, the engine evaluates this function across 50+ liquidity pools.</p>
                 <p>Capital acts like water, flowing toward the highest <span className="text-purple-400 font-mono">U(i)</span>, bottlenecked only by gas costs and slippage parameters.</p>
              </div>
           </div>
        </div>

        {/* Inputs & Parameters */}
        <div className="lg:col-span-8 flex flex-col gap-6">
           <div className="bg-white/5 border border-white/10 backdrop-blur-xl rounded-3xl p-6 flex-1">
              <h3 className="text-lg font-bold text-white mb-6 flex items-center gap-2 font-display">
                <Database className="text-blue-400" size={18} /> Model Inputs & Weights
              </h3>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                 <InputCard 
                    title="Real-Time APY (40%)" 
                    desc="Base yield + anticipated token emissions. Heavily discounted for impermanent loss."
                    icon={<Activity className="text-green-400" size={16} />}
                 />
                 <InputCard 
                    title="Smart Contract Risk (25%)" 
                    desc="Static heuristics. Aave = 9, New protocols = 4. Hard cutoff if score < 6."
                    icon={<ShieldAlert className="text-red-400" size={16} />}
                 />
                 <InputCard 
                    title="Liquidity Depth (20%)" 
                    desc="Non-linear penalty for low TVL. Ensures vault never owns >5% of a pool to prevent illiquidity."
                    icon={<Minimize2 className="text-blue-400" size={16} />}
                 />
                 <InputCard 
                    title="Volatility & Correlation (15%)" 
                    desc="Penalizes pairs highly correlated to toxic assets. Requires high Sharpe ratio."
                    icon={<Network className="text-purple-400" size={16} />}
                 />
              </div>
           </div>
        </div>

        {/* Risk Constraints */}
        <div className="lg:col-span-4 bg-white/5 border border-white/10 backdrop-blur-xl rounded-3xl p-6 border-t-4 border-t-red-500/50">
           <h3 className="text-lg font-bold text-white mb-6 flex items-center gap-2 font-display">
             <ShieldAlert className="text-red-400" size={18} /> Invariant Controls
           </h3>
           <p className="text-xs text-gray-400 mb-6 leading-relaxed">
             No matter what the engine decides, on-chain execution is bounded by non-negotiable smart constraints.
           </p>
           
           <ul className="space-y-4">
              <li className="flex gap-3 items-start">
                 <div className="w-6 h-6 rounded-full bg-red-500/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="text-red-400 text-xs font-bold">1</span>
                 </div>
                 <div>
                    <h4 className="text-sm font-semibold text-gray-200">Max Allocation</h4>
                    <p className="text-xs text-gray-500">Max 40% of vault TVL in any single protocol.</p>
                 </div>
              </li>
              <li className="flex gap-3 items-start">
                 <div className="w-6 h-6 rounded-full bg-red-500/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="text-red-400 text-xs font-bold">2</span>
                 </div>
                 <div>
                    <h4 className="text-sm font-semibold text-gray-200">Slippage Threshold</h4>
                    <p className="text-xs text-gray-500">Rebalance rejected if estimated slippage {'>'} 0.5%.</p>
                 </div>
              </li>
              <li className="flex gap-3 items-start">
                 <div className="w-6 h-6 rounded-full bg-red-500/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="text-red-400 text-xs font-bold">3</span>
                 </div>
                 <div>
                    <h4 className="text-sm font-semibold text-gray-200">Anti-Thrashing Check</h4>
                    <p className="text-xs text-gray-500">&Delta; Yield must exceed Base Layer 2 gas costs &times; 3.</p>
                 </div>
              </li>
           </ul>
        </div>

        {/* Execution Flow */}
        <div className="lg:col-span-12 bg-white/5 border border-white/10 backdrop-blur-xl rounded-3xl p-6">
            <h3 className="text-lg font-bold text-white mb-6 flex items-center gap-2 font-display">
               <RefreshCw className="text-[#00C2FF]" size={18} /> Rebalance Logic Loop
            </h3>
            
            <div className="flex flex-col md:flex-row items-stretch justify-between gap-4">
               <ProcessStep 
                  step="1" 
                  title="Ingest State" 
                  desc="Python worker pulls subgraphs, RPC state, and price feeds for Base chain."
               />
               <ProcessArrow />
               <ProcessStep 
                  step="2" 
                  title="Score & Predict" 
                  desc="Engine runs risk-adjusted heuristic scoring for 50+ whitelisted vaults."
               />
               <ProcessArrow />
               <ProcessStep 
                  step="3" 
                  title="Delta Constraint" 
                  desc="Condition: (New Yield - Old Yield) > Gas + Slippage penalty."
               />
               <ProcessArrow />
               <ProcessStep 
                  step="4" 
                  title="Gelato Execute" 
                  desc="Relayer securely fires tx to Vault Contract via AI_KEEPER_ROLE."
               />
            </div>
        </div>

        {/* Web3 Automation Integrations */}
        <div className="lg:col-span-12 bg-gradient-to-r from-[#020617] to-purple-900/20 border border-purple-500/20 backdrop-blur-xl rounded-3xl p-6">
            <h3 className="text-lg font-bold text-white mb-6 flex items-center gap-2 font-display">
               <Bot className="text-purple-400" size={20} /> Web3 Automation & Keeper Network Check
            </h3>

            {!isConnected ? (
               <div className="text-center py-6 text-gray-400 text-sm">
                  Connect your wallet to check your keeper status.
               </div>
            ) : isKeeper ? (
               <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
                  <div className="bg-white/5 border border-purple-500/30 rounded-2xl p-5 relative">
                     <div className="absolute top-0 right-0 w-24 h-24 bg-purple-500/10 blur-[40px] rounded-full pointer-events-none"></div>
                     <h4 className="text-white font-bold mb-1 flex items-center gap-2"><RefreshCw size={16} className="text-purple-400" /> Auto-Rebalancer (Simulate)</h4>
                     <p className="text-xs text-gray-400 mb-4">You hold the <code className="text-purple-300">AI_KEEPER_ROLE</code>. You can manually fire the underlying relayer function here.</p>
                     
                     <div className="space-y-3">
                       <input 
                         type="text" 
                         value={strategyAddress} 
                         onChange={(e) => setStrategyAddress(e.target.value)}
                         placeholder="Strategy Adapter Address (0x...)"
                         className="w-full bg-[#020617] border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-purple-500/50"
                       />
                       <input 
                         type="text" 
                         value={rebalanceAmount} 
                         onChange={(e) => setRebalanceAmount(e.target.value)}
                         placeholder="USDC Amount (e.g. 100)"
                         className="w-full bg-[#020617] border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-purple-500/50"
                       />
                       <button 
                         onClick={handleRebalance}
                         disabled={isRebalancingTx || isWaitingRebalance || !strategyAddress || !rebalanceAmount}
                         className="w-full py-2.5 bg-purple-600 hover:bg-purple-500 rounded-xl text-sm font-semibold text-white transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                       >
                         {isRebalancingTx || isWaitingRebalance ? 'Relaying...' : <><Zap size={16} /> Execute Rebalance</>}
                       </button>

                       {isRebalanceSuccess && rebalanceHash && (
                         <div className="text-center mt-2">
                           <a href={`https://basescan.org/tx/${rebalanceHash}`} target="_blank" rel="noreferrer" className="text-xs text-green-400 hover:text-green-300 flex items-center justify-center gap-1">
                             Tx Confirmed <ExternalLink size={10} />
                           </a>
                         </div>
                       )}
                     </div>
                  </div>

                  <div className="bg-white/5 border border-purple-500/30 rounded-2xl p-5 relative">
                     <h4 className="text-white font-bold mb-1 flex items-center gap-2"><BarChart3 size={16} className="text-green-400" /> Yield Harvester</h4>
                     <p className="text-xs text-gray-400 mb-4">Fires the smart contract to socialize yield, mint performance fees, and push high watermark.</p>
                     
                     <div className="pt-2">
                       <button 
                         onClick={handleHarvest}
                         disabled={isHarvestingTx || isWaitingHarvest}
                         className="w-full py-2.5 bg-white/10 hover:bg-white/20 border border-white/20 rounded-xl text-sm font-semibold text-white transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                       >
                         {isHarvestingTx || isWaitingHarvest ? 'Executing...' : 'Trigger Harvest()'}
                       </button>

                       {isHarvestingTx && <p className="text-xs text-yellow-400 text-center mt-3">Confirming in wallet...</p>}
                       {isHarvestSuccess && harvestHash && (
                         <div className="text-center mt-3">
                           <a href={`https://basescan.org/tx/${harvestHash}`} target="_blank" rel="noreferrer" className="text-xs text-green-400 hover:text-green-300 flex items-center justify-center gap-1">
                             Harvest Confirmed <ExternalLink size={10} />
                           </a>
                         </div>
                       )}
                     </div>
                  </div>
               </div>
            ) : (
               <div className="bg-[#020617]/50 rounded-2xl p-6 border border-white/5 text-center space-y-2 mt-4">
                  <div className="w-12 h-12 rounded-full bg-purple-500/20 flex items-center justify-center mx-auto mb-3">
                    <ShieldAlert className="text-purple-400" size={24} />
                  </div>
                  <h4 className="text-white font-semibold">Web3 Automation Active</h4>
                  <p className="text-sm text-gray-400 max-w-lg mx-auto">
                    The smart contract is actively monitored by a decentralized keeper network. 
                    Your current wallet address does not hold the <code className="text-purple-300">AI_KEEPER_ROLE</code>, so you cannot manually trigger Rebalance or Harvest functions.
                  </p>
               </div>
            )}
        </div>

      </div>
    </div>
  );
}

function InputCard({ title, desc, icon }: { title: string, desc: string, icon: React.ReactNode }) {
  return (
    <div className="p-4 rounded-2xl bg-[#020617]/40 border border-white/5 hover:bg-white/5 transition-colors">
      <div className="flex items-center gap-2 mb-2">
        {icon}
        <h4 className="text-sm font-semibold text-gray-200">{title}</h4>
      </div>
      <p className="text-xs text-gray-500 leading-relaxed">{desc}</p>
    </div>
  );
}

function ProcessStep({ step, title, desc }: { step: string, title: string, desc: string }) {
  return (
    <div className="flex-1 bg-white/5 border border-white/5 rounded-2xl p-4 relative group hover:border-[#00C2FF]/30 transition-colors">
       <span className="absolute -top-3 -right-3 w-8 h-8 rounded-full bg-[#00C2FF]/20 text-[#00C2FF] border border-[#00C2FF]/30 flex items-center justify-center font-mono font-bold text-sm">
         {step}
       </span>
       <h4 className="text-white font-semibold text-sm mb-2">{title}</h4>
       <p className="text-xs text-gray-400">{desc}</p>
    </div>
  );
}

function ProcessArrow() {
  return (
    <div className="hidden md:flex items-center justify-center px-2">
       <div className="h-0.5 w-8 bg-gradient-to-r from-transparent via-[#00C2FF]/50 to-[#00C2FF]/50 relative">
          <div className="absolute right-0 top-1/2 -translate-y-1/2 w-2 h-2 border-t-2 border-r-2 border-[#00C2FF]/50 rotate-45"></div>
       </div>
    </div>
  );
}
