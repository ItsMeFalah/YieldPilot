import React from 'react';
import { ArrowDownLeft, ArrowUpRight, Wallet, TrendingUp, History, ExternalLink, Zap } from 'lucide-react';
import { useVault } from '../lib/VaultContext';
import { useAccount, useReadContract, useReadContracts } from 'wagmi';
import { formatUnits } from 'viem';
import { vaultAbi, VAULT_ADDRESS } from '../lib/contracts';

export default function DashboardPage({ onNavigateDeposit }: { onNavigateDeposit?: () => void }) {
  const { address } = useAccount();

  // Read User Vault Shares and Total Assets
  const { data: sharesData } = useReadContract({
    address: VAULT_ADDRESS as `0x${string}`,
    abi: vaultAbi,
    functionName: 'balanceOf',
    args: address ? [address] : undefined,
    query: {
      enabled: !!address,
    }
  });

  const { data: assetsData } = useReadContract({
    address: VAULT_ADDRESS as `0x${string}`,
    abi: vaultAbi,
    functionName: 'convertToAssets',
    args: sharesData ? [sharesData as bigint] : undefined,
    query: {
      enabled: !!sharesData,
    }
  });

  const { history } = useVault();

  const userShares = sharesData ? Number(formatUnits(sharesData as bigint, 6)) : 0;
  const userAssets = assetsData ? Number(formatUnits(assetsData as bigint, 6)) : 0;
  
  // Fake yield calculation until the vault actually generates yield
  const earnedYield = Math.max(0, userAssets - userShares); 
  const depositedBalance = userShares;

  const activeStrategies = [
    { name: 'Aerodrome V2 (USDC/cbETH)', yield: '14.2%', allocation: '52%', tvl: '$124M', status: 'Optimal' },
    { name: 'Moonwell (USDC Supply)', yield: '8.4%', allocation: '28%', tvl: '$68M', status: 'Rebalancing' },
    { name: 'Aave V3 (USDC Reserve)', yield: '6.1%', allocation: '20%', tvl: '$95M', status: 'Stable' }
  ];

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      
      {/* Top Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white/5 border border-white/10 backdrop-blur-xl rounded-3xl p-6 relative overflow-hidden">
           <div className="absolute top-0 right-0 w-32 h-32 bg-[#0052FF]/10 blur-[50px] rounded-full pointer-events-none"></div>
           <div className="flex items-center gap-3 text-gray-400 mb-4">
              <Wallet size={18} />
              <h2 className="text-sm font-semibold uppercase tracking-wider">Total Portfolio</h2>
           </div>
           <div className="text-4xl font-display font-bold text-white mb-2 flex items-baseline gap-1">
             <span className="text-xl text-gray-500">$</span>
             {(depositedBalance + earnedYield).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 4 })}
           </div>
           <p className="text-sm text-green-400 font-medium">+${earnedYield.toFixed(4)} ({depositedBalance > 0 ? ((earnedYield / depositedBalance) * 100).toFixed(4) : '0.00'}%) All Time</p>
        </div>

        <div className="bg-white/5 border border-white/10 backdrop-blur-xl rounded-3xl p-6 relative overflow-hidden">
           <div className="flex items-center gap-3 text-gray-400 mb-4">
              <TrendingUp size={18} />
              <h2 className="text-sm font-semibold uppercase tracking-wider">Net APY</h2>
           </div>
           <div className="text-4xl font-display font-bold text-[#00C2FF] mb-2 flex items-baseline gap-1">
             8.90<span className="text-xl text-[#00C2FF]/70">%</span>
           </div>
           <p className="text-sm text-gray-400 font-medium tracking-wide">30-Day Trailing Average</p>
        </div>

        <div className="bg-white/5 border border-white/10 backdrop-blur-xl rounded-3xl p-6 relative overflow-hidden">
           <div className="flex items-center gap-3 text-gray-400 mb-4">
              <History size={18} />
              <h2 className="text-sm font-semibold uppercase tracking-wider">Total Earned</h2>
           </div>
           <div className="text-4xl font-display font-bold text-white mb-2 flex items-baseline gap-1">
             <span className="text-xl text-gray-500">$</span>
             {earnedYield.toLocaleString(undefined, { minimumFractionDigits: 4, maximumFractionDigits: 6 })}
           </div>
           <p className="text-sm text-gray-400 font-medium tracking-wide">Since Inception</p>
        </div>
      </div>

      <div className="bg-gradient-to-r from-blue-500/10 to-purple-500/10 border border-blue-500/20 backdrop-blur-xl rounded-3xl p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
             <div className="w-10 h-10 rounded-xl bg-blue-500/20 flex items-center justify-center border border-blue-500/30">
               <Zap className="text-blue-400 w-5 h-5" />
             </div>
             <div>
               <h3 className="text-lg font-display font-bold text-white leading-tight">Live AI Routing</h3>
               <p className="text-sm text-gray-400">Capital actively deployed to highest-yielding strategies on Base</p>
             </div>
          </div>
          <div className="hidden sm:flex px-4 py-2 bg-white/5 border border-white/10 rounded-full text-xs font-medium text-gray-300">
             Next Rebalance in 04:29
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {activeStrategies.map((strategy, i) => (
            <div key={i} className="bg-[#020617]/50 border border-white/5 rounded-2xl p-5 hover:bg-white/5 transition-colors group">
               <div className="flex justify-between items-start mb-4">
                  <div className="text-sm font-semibold text-white group-hover:text-blue-400 transition-colors">{strategy.name}</div>
                  <div className="px-2 py-1 rounded bg-green-500/10 text-green-400 text-xs font-bold font-mono">
                    {strategy.yield} APY
                  </div>
               </div>
               
               <div className="flex items-end justify-between">
                  <div>
                    <div className="text-xs text-gray-500 mb-1">Target Allocation</div>
                    <div className="text-lg font-mono text-white">{strategy.allocation}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-xs text-gray-500 mb-1">Protocol TVL</div>
                    <div className="text-sm text-gray-300">{strategy.tvl}</div>
                  </div>
               </div>
            </div>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
         {/* Asset Breakdown */}
         <div className="lg:col-span-2 bg-white/5 border border-white/10 backdrop-blur-xl rounded-3xl p-6">
            <h3 className="text-lg font-display font-bold text-white mb-6">Vault Positions</h3>
            
            <div className="overflow-x-auto">
              {depositedBalance > 0 ? (
                <table className="w-full text-left">
                   <thead>
                      <tr className="text-xs uppercase tracking-wider text-gray-500 border-b border-white/10">
                         <th className="pb-4 font-semibold">Asset</th>
                         <th className="pb-4 font-semibold">Balance</th>
                         <th className="pb-4 font-semibold">Current APY</th>
                         <th className="pb-4 font-semibold text-right">Value</th>
                      </tr>
                   </thead>
                   <tbody>
                      <tr className="border-b border-white/5 hover:bg-white/5 transition-colors group">
                         <td className="py-4">
                            <div className="flex items-center gap-3">
                               <div className="w-8 h-8 rounded-full bg-blue-500/20 flex items-center justify-center border border-blue-500/30 font-bold text-blue-400 text-xs">USDC</div>
                               <div>
                                  <div className="font-semibold text-white">YieldPilot USDC</div>
                                  <div className="text-xs text-gray-500">ypUSDC (Base)</div>
                               </div>
                            </div>
                         </td>
                         <td className="py-4 font-mono text-sm text-gray-300">{(depositedBalance + earnedYield).toFixed(4)}</td>
                         <td className="py-4 text-sm text-green-400 font-medium">8.90%</td>
                         <td className="py-4 font-mono text-sm text-white text-right">${(depositedBalance + earnedYield).toFixed(2)}</td>
                      </tr>
                   </tbody>
                </table>
              ) : (
                <div className="py-12 text-center">
                   <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center mx-auto mb-4 border border-white/10">
                      <Wallet className="text-gray-500" size={24} />
                   </div>
                   <h4 className="text-white font-semibold mb-2">No Active Deposits</h4>
                   <p className="text-sm text-gray-400 max-w-sm mx-auto mb-6">You haven't deposited any assets into YieldPilot yet. Start earning auto-compounding yields entirely passively.</p>
                   <button 
                      onClick={onNavigateDeposit}
                      className="px-6 py-2 bg-white/10 hover:bg-white/20 border border-white/20 rounded-full text-sm font-semibold transition-all"
                   >
                      Go to Deposit
                   </button>
                </div>
              )}
            </div>
         </div>

         {/* Recent Activity */}
         <div className="lg:col-span-1 bg-white/5 border border-white/10 backdrop-blur-xl rounded-3xl p-6">
            <h3 className="text-lg font-display font-bold text-white mb-6">Recent Activity</h3>
            
            <div className="space-y-4">
               {history.length > 0 ? history.map(tx => (
                 <div key={tx.id} className="flex justify-between items-center bg-white/5 p-3 rounded-xl border border-white/5">
                   <div className="flex items-center gap-3">
                      <div className={`p-2 rounded-lg ${tx.type === 'deposit' ? 'bg-green-500/10 text-green-400' : 'bg-red-500/10 text-red-400'}`}>
                         {tx.type === 'deposit' ? <ArrowDownLeft size={16} /> : <ArrowUpRight size={16} /> }
                      </div>
                      <div>
                         <div className="text-sm font-semibold capitalize text-white">{tx.type} USDC</div>
                         <div className="text-xs text-gray-500">{tx.date.toLocaleDateString()}</div>
                      </div>
                   </div>
                   <div className="text-right">
                      <div className="text-sm font-mono text-white">${tx.amount.toFixed(2)}</div>
                      <a href={`https://basescan.org/tx/${tx.txHash}`} target="_blank" rel="noreferrer" className="text-xs text-blue-400 hover:text-blue-300 flex items-center gap-1 justify-end mt-1">
                        View <ExternalLink size={10} />
                      </a>
                   </div>
                 </div>
               )) : (
                 <div className="text-center py-8">
                    <div className="text-gray-500 text-sm mb-2">No recent transactions</div>
                    <div className="text-xs text-gray-600">Your deposit and withdrawal history will appear here.</div>
                 </div>
               )}
            </div>
         </div>
      </div>
    </div>
  );
}
