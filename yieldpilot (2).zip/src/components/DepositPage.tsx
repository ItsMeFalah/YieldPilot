import React, { useState, useEffect } from 'react';
import { ArrowDownLeft, ShieldCheck, Settings, AlertCircle, Wallet, ExternalLink, AlertTriangle } from 'lucide-react';
import { cn } from '../lib/utils';
import { useAccount, useConnect, useReadContract, useWriteContract, useWaitForTransactionReceipt, useSwitchChain } from 'wagmi';
import { injected } from 'wagmi/connectors';
import { parseUnits, formatUnits } from 'viem';
import { base } from 'wagmi/chains';
import { vaultAbi, erc20Abi, VAULT_ADDRESS, USDC_ADDRESS } from '../lib/contracts';

export default function DepositPage() {
  const [activeTab, setActiveTab] = useState<'deposit' | 'withdraw'>('deposit');
  const [amount, setAmount] = useState<string>('');
  
  const { isConnected, address, chainId } = useAccount();
  const { connect } = useConnect();
  const { switchChain } = useSwitchChain();

  const isWrongNetwork = isConnected && chainId !== base.id;

  // Read USDC Balance
  const { data: usdcBalanceData, refetch: refetchUsdc } = useReadContract({
    address: USDC_ADDRESS as `0x${string}`,
    abi: erc20Abi,
    functionName: 'balanceOf',
    args: address ? [address] : undefined,
    query: {
      enabled: !!address,
    }
  });

  // Read Vault Balance (ypUSDC)
  const { data: vaultBalanceData, refetch: refetchVault } = useReadContract({
    address: VAULT_ADDRESS as `0x${string}`,
    abi: vaultAbi,
    functionName: 'balanceOf',
    args: address ? [address] : undefined,
    query: {
      enabled: !!address,
    }
  });

  // Read Allowance
  const { data: allowanceData, refetch: refetchAllowance } = useReadContract({
    address: USDC_ADDRESS as `0x${string}`,
    abi: erc20Abi,
    functionName: 'allowance',
    args: address ? [address, VAULT_ADDRESS as `0x${string}`] : undefined,
    query: {
      enabled: !!address,
    }
  });

  const { writeContract: writeApprove, data: approveHash, isPending: isApproving } = useWriteContract();
  const { writeContract: writeDeposit, data: depositHash, isPending: isDepositingTx } = useWriteContract();
  const { writeContract: writeWithdraw, data: withdrawHash, isPending: isWithdrawingTx } = useWriteContract();

  const { isLoading: isWaitingApprove, isSuccess: isApproveSuccess } = useWaitForTransactionReceipt({ hash: approveHash });
  const { isLoading: isWaitingDeposit, isSuccess: isDepositSuccess } = useWaitForTransactionReceipt({ hash: depositHash });
  const { isLoading: isWaitingWithdraw, isSuccess: isWithdrawSuccess } = useWaitForTransactionReceipt({ hash: withdrawHash });

  useEffect(() => {
    if (isApproveSuccess) refetchAllowance();
  }, [isApproveSuccess, refetchAllowance]);

  useEffect(() => {
    if (isDepositSuccess || isWithdrawSuccess) {
      refetchUsdc();
      refetchVault();
      setAmount('');
    }
  }, [isDepositSuccess, isWithdrawSuccess, refetchUsdc, refetchVault]);

  const usdcDecimals = 6;
  const usdcBalanceString = usdcBalanceData ? formatUnits(usdcBalanceData as bigint, usdcDecimals) : '0';
  const vaultBalanceString = vaultBalanceData ? formatUnits(vaultBalanceData as bigint, usdcDecimals) : '0';
  
  const availableDeposit = Number(usdcBalanceString);
  const availableWithdraw = Number(vaultBalanceString);
  const currentMax = activeTab === 'deposit' ? availableDeposit : availableWithdraw;

  const handleTransaction = () => {
    if (!isConnected) {
      connect({ connector: injected() });
      return;
    }
    
    if (isWrongNetwork) {
      switchChain({ chainId: base.id });
      return;
    }
    
    if (!amount || isNaN(Number(amount)) || Number(amount) <= 0) return;

    // Prevent trying to interact with the 0x0 placeholder
    if (VAULT_ADDRESS === '0x0000000000000000000000000000000000000000') {
      alert("Missing Smart Contract: Please deploy YieldPilotVault.sol and update VAULT_ADDRESS in src/lib/contracts.ts before transacting.");
      return;
    }

    const valueBigInt = parseUnits(amount, usdcDecimals);

    if (activeTab === 'deposit') {
      const allowance = allowanceData ? (allowanceData as bigint) : 0n;
      if (allowance < valueBigInt) {
        writeApprove({
          address: USDC_ADDRESS as `0x${string}`,
          abi: erc20Abi,
          functionName: 'approve',
          args: [VAULT_ADDRESS as `0x${string}`, valueBigInt],
        });
      } else {
        writeDeposit({
          address: VAULT_ADDRESS as `0x${string}`,
          abi: vaultAbi,
          functionName: 'deposit',
          args: [valueBigInt, address as `0x${string}`],
        });
      }
    } else {
      writeWithdraw({
        address: VAULT_ADDRESS as `0x${string}`,
        abi: vaultAbi,
        functionName: 'withdraw',
        args: [valueBigInt, address as `0x${string}`, address as `0x${string}`],
      });
    }
  };

  const isProcessing = isApproving || isWaitingApprove || isDepositingTx || isWaitingDeposit || isWithdrawingTx || isWaitingWithdraw;

  const getButtonText = () => {
    if (!isConnected) return <><Wallet size={20} /> Connect Wallet</>;
    if (isWrongNetwork) return <><AlertTriangle size={20} /> Switch to Base</>;
    if (isApproving || isWaitingApprove) return 'Approving USDC...';
    if (isDepositingTx || isWaitingDeposit) return 'Depositing...';
    if (isWithdrawingTx || isWaitingWithdraw) return 'Withdrawing...';
    
    if (activeTab === 'deposit') {
      const val = amount ? parseUnits(amount, usdcDecimals) : 0n;
      const allowance = allowanceData ? (allowanceData as bigint) : 0n;
      if (val > 0n && allowance < val) {
        return 'Approve USDC';
      }
      return 'Deposit USDC';
    }
    return 'Withdraw ypUSDC';
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6 pt-4">
      
      {VAULT_ADDRESS === '0x0000000000000000000000000000000000000000' && (
        <div className="bg-yellow-500/10 border border-yellow-500/20 text-yellow-500 rounded-2xl p-4 flex gap-3 text-sm animate-in fade-in slide-in-from-top-4">
          <AlertCircle className="shrink-0 mt-0.5" size={18} />
          <div>
            <strong>Developer Mode Active</strong>
            <p className="mt-1 text-yellow-500/80">Configure your smart contract address in <code className="bg-yellow-500/20 px-1 py-0.5 rounded">src/lib/contracts.ts</code> to enable live Base transactions.</p>
          </div>
        </div>
      )}

      <div className="bg-white/5 border border-white/10 backdrop-blur-xl rounded-[2rem] p-6 sm:p-8 relative overflow-hidden shadow-2xl">
         <div className="absolute top-0 right-0 w-64 h-64 bg-[#0052FF]/10 blur-[80px] rounded-full pointer-events-none"></div>
         
         <div className="flex bg-white/5 p-1.5 rounded-2xl mb-8 border border-white/10 relative z-10 w-full md:w-3/4 mx-auto">
           <button 
             onClick={() => { setActiveTab('deposit'); setAmount(''); }}
             className={cn("flex-1 py-2.5 text-sm font-bold rounded-xl transition-all", activeTab === 'deposit' ? 'bg-white/10 text-white shadow-md border border-white/10' : 'text-gray-500 hover:text-white hover:bg-white/5')}
           >
             Deposit
           </button>
           <button 
             onClick={() => { setActiveTab('withdraw'); setAmount(''); }}
             className={cn("flex-1 py-2.5 text-sm font-bold rounded-xl transition-all", activeTab === 'withdraw' ? 'bg-white/10 text-white shadow-md border border-white/10' : 'text-gray-500 hover:text-white hover:bg-white/5')}
           >
             Withdraw
           </button>
         </div>

         <div className="space-y-6 relative z-10">
            
            <div className="bg-[#020617]/50 rounded-2xl p-5 border border-white/5 focus-within:border-[#0052FF]/50 transition-colors">
               <div className="flex justify-between items-center mb-3">
                  <span className="text-xs font-semibold text-gray-400 uppercase tracking-widest">{activeTab === 'deposit' ? 'You Pay' : 'You Redeem'}</span>
                  <span className="text-xs text-gray-500">
                    Balance: <span className="font-mono text-gray-300">
                      {isConnected ? currentMax.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 4 }) : '0.00'}
                    </span>
                  </span>
               </div>
               
               <div className="flex justify-between items-center gap-4">
                  <input 
                    type="text" 
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="0.00"
                    className="flex-1 bg-transparent text-4xl text-white font-mono placeholder:text-gray-700 outline-none w-full"
                  />
                  
                  <div className="flex items-center gap-2 bg-white/5 border border-white/10 rounded-xl p-2 shrink-0">
                     <div className="w-6 h-6 rounded-full bg-blue-500 flex items-center justify-center">
                        <div className="w-2 h-2 bg-white rounded-full"></div>
                     </div>
                     <span className="font-bold text-white pr-1">{activeTab === 'deposit' ? 'USDC' : 'ypUSDC'}</span>
                  </div>
               </div>
               
               {isConnected && (
                 <div className="flex gap-2 mt-4">
                    <button onClick={() => setAmount(String(currentMax * 0.25))} className="px-3 py-1 bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg text-xs font-medium text-gray-400 transition-colors">
                       25%
                    </button>
                    <button onClick={() => setAmount(String(currentMax * 0.5))} className="px-3 py-1 bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg text-xs font-medium text-gray-400 transition-colors">
                       50%
                    </button>
                    <button onClick={() => setAmount(String(currentMax))} className="px-3 py-1 bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg text-xs font-medium text-gray-400 transition-colors">
                       MAX
                    </button>
                 </div>
               )}
            </div>

            <div className="space-y-3 px-2">
               <div className="flex justify-between items-center text-sm">
                  <span className="text-gray-400">Current APY</span>
                  <span className="text-green-400 font-bold">8.90%</span>
               </div>
               <div className="flex justify-between items-center text-sm">
                  <span className="text-gray-400">Exchange Rate</span>
                  <span className="text-white font-mono">1 ypUSDC = 1.042 USDC</span>
               </div>
               <div className="flex justify-between items-center text-sm">
                  <span className="text-gray-400 flex items-center gap-1">Network Base <Settings size={12} /></span>
                  <span className="text-white font-mono">Live On-Chain</span>
               </div>
            </div>

            <div className="bg-blue-500/10 border border-blue-500/20 rounded-xl p-4 flex gap-3 text-sm">
               <ShieldCheck className="text-blue-400 shrink-0 mt-0.5" size={18} />
               <p className="text-blue-200/80 leading-relaxed">
                  Your funds are autonomously routed to the highest-yielding strategies on Base. No lock-up periods. Assets can be withdrawn instantly at any time.
               </p>
            </div>

            <button 
               onClick={handleTransaction}
               disabled={isProcessing || (isConnected && !isWrongNetwork && (!amount || Number(amount) <= 0 || Number(amount) > currentMax))}
               className="w-full py-4 bg-gradient-to-r from-[#0052FF] to-[#0085FF] rounded-2xl font-bold text-lg shadow-xl shadow-blue-500/20 hover:scale-[1.02] active:scale-95 transition-transform disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100 flex items-center justify-center gap-2 text-white border-0 mt-2"
             >
               {getButtonText()}
             </button>
             
             {isDepositSuccess && (
               <div className="text-center text-sm text-green-400 flex items-center justify-center gap-2">
                  Deposit successful! <a href={`https://basescan.org/tx/${depositHash}`} target="_blank" rel="noreferrer" className="underline flex items-center gap-1">View on Basescan <ExternalLink size={12}/></a>
               </div>
             )}
             
             {isWithdrawSuccess && (
               <div className="text-center text-sm text-green-400 flex items-center justify-center gap-2">
                  Withdrawal successful! <a href={`https://basescan.org/tx/${withdrawHash}`} target="_blank" rel="noreferrer" className="underline flex items-center gap-1">View on Basescan <ExternalLink size={12}/></a>
               </div>
             )}

         </div>
      </div>
    </div>
  );
}

