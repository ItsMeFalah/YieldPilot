import React from 'react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, BarChart, Bar, Legend, Cell } from 'recharts';
import { PieChart, Pie } from 'recharts';
import { ShieldCheck, TrendingUp, Activity } from 'lucide-react';

const mockTVLData = [
  { date: 'Oct 01', tvl: 420000 },
  { date: 'Oct 08', tvl: 480000 },
  { date: 'Oct 15', tvl: 550000 },
  { date: 'Oct 22', tvl: 530000 },
  { date: 'Oct 29', tvl: 610000 },
  { date: 'Nov 05', tvl: 742880 },
];

const mockAllocationData = [
  { name: 'Aerodrome V2', value: 52, color: '#0052FF' },
  { name: 'Moonwell', value: 28, color: '#8b5cf6' },
  { name: 'Aave V3', value: 20, color: '#10b981' },
];

export default function AnalyticsPage() {
  return (
    <div className="max-w-7xl mx-auto space-y-6">
      
      <div className="flex items-center justify-between mb-8">
         <h1 className="font-display text-3xl font-bold text-white tracking-tight">Analytics & Protocol Data</h1>
         <div className="px-3 py-1 bg-green-500/10 border border-green-500/20 text-green-400 rounded-full text-xs font-mono font-bold flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse"></span>
            System Healthy
         </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
         {/* KPI Cards */}
         <div className="bg-white/5 border border-white/10 backdrop-blur-xl rounded-3xl p-6">
            <p className="text-gray-400 text-sm font-semibold uppercase tracking-wider mb-2">Total Value Locked</p>
            <p className="text-3xl font-display font-bold text-white">$742,880</p>
            <p className="text-xs text-green-400 mt-2 font-medium">+12.5% this week</p>
         </div>
         <div className="bg-white/5 border border-white/10 backdrop-blur-xl rounded-3xl p-6">
            <p className="text-gray-400 text-sm font-semibold uppercase tracking-wider mb-2">Blended APY</p>
            <p className="text-3xl font-display font-bold text-[#00C2FF]">8.90%</p>
            <p className="text-xs text-gray-500 mt-2 font-medium">Net of performance fees</p>
         </div>
         <div className="bg-white/5 border border-white/10 backdrop-blur-xl rounded-3xl p-6">
            <p className="text-gray-400 text-sm font-semibold uppercase tracking-wider mb-2">AI Rebalances (30d)</p>
            <p className="text-3xl font-display font-bold text-white">142</p>
            <p className="text-xs text-gray-500 mt-2 font-medium">~4.7 per day</p>
         </div>
         <div className="bg-white/5 border border-white/10 backdrop-blur-xl rounded-3xl p-6">
            <p className="text-gray-400 text-sm font-semibold uppercase tracking-wider mb-2">Risk Score</p>
            <p className="text-3xl font-display font-bold text-white">AAA</p>
            <p className="text-xs text-green-400 mt-2 font-medium">0% Bad Debt</p>
         </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
         
         {/* TVL Growth Chart */}
         <div className="lg:col-span-2 bg-white/5 border border-white/10 backdrop-blur-xl rounded-3xl p-6 h-[400px] flex flex-col">
            <div className="flex justify-between items-start mb-6">
               <div>
                  <h2 className="text-lg font-display font-bold text-white">TVL Growth</h2>
                  <p className="text-sm text-gray-400 mt-1">Total liquidity managed by YieldPilot AI.</p>
               </div>
            </div>
            <div className="flex-1 w-full relative">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={mockTVLData} margin={{ top: 10, right: 0, left: 0, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorTvl" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#00C2FF" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#00C2FF" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="date" axisLine={false} tickLine={false} tick={{fill: '#6b7280', fontSize: 12}} dy={10} />
                  <YAxis hide domain={['dataMin - 50000', 'auto']} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: 'rgba(255,255,255,0.05)', borderColor: 'rgba(255,255,255,0.1)', color: '#fff', borderRadius: '1rem', backdropFilter: 'blur(16px)' }}
                    itemStyle={{ color: '#00C2FF', fontFamily: 'monospace' }}
                    formatter={(value: number) => [`$${value.toLocaleString()}`, 'TVL']}
                  />
                  <Area type="monotone" dataKey="tvl" stroke="#00C2FF" strokeWidth={3} fillOpacity={1} fill="url(#colorTvl)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
         </div>

         {/* Allocation Pie Chart */}
         <div className="lg:col-span-1 bg-white/5 border border-white/10 backdrop-blur-xl rounded-3xl p-6 flex flex-col">
            <div className="mb-2">
               <h2 className="text-lg font-display font-bold text-white">Current Allocation</h2>
               <p className="text-sm text-gray-400 mt-1">Real-time routing across highest-yielding Base protocols.</p>
            </div>
            
            <div className="flex-1 flex justify-center items-center -my-4 h-48">
               <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                     <Pie
                        data={mockAllocationData}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={80}
                        paddingAngle={5}
                        dataKey="value"
                     >
                        {mockAllocationData.map((entry, index) => (
                           <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                     </Pie>
                     <Tooltip 
                       contentStyle={{ backgroundColor: 'rgba(255,255,255,0.05)', borderColor: 'rgba(255,255,255,0.1)', color: '#fff', borderRadius: '1rem', backdropFilter: 'blur(16px)' }}
                       itemStyle={{ color: '#fff', fontFamily: 'monospace' }}
                     />
                  </PieChart>
               </ResponsiveContainer>
            </div>

            <div className="space-y-3 mt-4">
               {mockAllocationData.map((item, i) => (
                  <div key={i} className="flex items-center justify-between">
                     <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }}></div>
                        <span className="text-sm text-gray-300 font-medium">{item.name}</span>
                     </div>
                     <span className="text-sm font-mono text-white">{item.value}%</span>
                  </div>
               ))}
            </div>
         </div>

      </div>
    </div>
  );
}
