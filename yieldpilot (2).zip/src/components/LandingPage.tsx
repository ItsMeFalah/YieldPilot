import React from 'react';
import { ArrowRight, Activity, ShieldCheck, Zap, Layers } from 'lucide-react';
import ConnectButton from './ConnectButton';

interface LandingPageProps {
  onEnterApp: () => void;
}

export default function LandingPage({ onEnterApp }: LandingPageProps) {
  return (
    <div className="min-h-screen bg-[#020617] text-white overflow-hidden relative flex flex-col justify-center items-center">
      {/* Background Orbs */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-[#0052FF]/20 rounded-full blur-[120px] pointer-events-none"></div>
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-[#00C2FF]/10 rounded-full blur-[120px] pointer-events-none"></div>

      <nav className="absolute top-0 w-full px-8 py-6 flex justify-between items-center z-10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-tr from-[#0052FF] to-[#00C2FF] rounded-xl flex items-center justify-center shadow-lg shadow-blue-500/20">
            <Layers className="text-white w-6 h-6" />
          </div>
          <span className="font-display font-bold text-2xl tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-white to-gray-400">
            YieldPilot
          </span>
        </div>
        <div className="flex items-center gap-4">
          <button 
            onClick={onEnterApp}
            className="px-6 py-2.5 bg-white/10 hover:bg-white/20 border border-white/20 rounded-full text-sm font-semibold transition-all backdrop-blur-md hidden sm:block"
          >
            Launch App
          </button>
          <ConnectButton />
        </div>
      </nav>

      <main className="relative z-10 flex flex-col items-center justify-center max-w-5xl mx-auto px-4 text-center mt-20">
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-semibold uppercase tracking-wider mb-8">
          <span className="w-2 h-2 rounded-full bg-blue-400 animate-pulse"></span>
          Live on Base Mainnet
        </div>
        
        <h1 className="text-5xl sm:text-7xl font-display font-bold tracking-tight mb-8 leading-[1.1]">
          AI-Powered Capital <br className="hidden sm:block" />
          <span className="bg-clip-text text-transparent bg-gradient-to-r from-[#0052FF] via-[#00C2FF] to-purple-400">
            Allocation on Base
          </span>
        </h1>
        
        <p className="text-lg sm:text-xl text-gray-400 max-w-2xl mb-12 font-sans leading-relaxed">
          Deposit USDC and let our quantitative AI model instantly route your capital to the safest, highest-yielding DeFi opportunities. No manual management required.
        </p>

        <div className="flex flex-col sm:flex-row items-center gap-4 mb-24">
          <button 
            onClick={onEnterApp}
            className="w-full sm:w-auto px-8 py-4 bg-gradient-to-r from-[#0052FF] to-[#0085FF] rounded-full font-bold text-lg shadow-xl shadow-blue-500/20 hover:scale-[1.02] active:scale-95 transition-all flex items-center justify-center gap-2"
          >
            Enter App <ArrowRight size={20} />
          </button>
          <button className="w-full sm:w-auto px-8 py-4 bg-white/5 hover:bg-white/10 border border-white/10 rounded-full font-bold text-lg transition-all hidden">
            Read Docs
          </button>
        </div>

        {/* Feature Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full text-left">
           <FeatureCard 
              icon={<Zap className="text-[#00C2FF]" />}
              title="Instant Optimization"
              description="Our model evaluates 50+ liquidity pools every 10 minutes to auto-compound and maximize APY."
           />
           <FeatureCard 
              icon={<ShieldCheck className="text-green-400" />}
              title="Minimzed Risk"
              description="Strict smart contract heuristics ensure capital only flows to battle-tested, highly liquid protocols."
           />
           <FeatureCard 
              icon={<Activity className="text-purple-400" />}
              title="Complete Transparency"
              description="View the exact mathematical utility score and reasoning behind every on-chain AI rebalance."
           />
        </div>
      </main>
    </div>
  );
}

function FeatureCard({ icon, title, description }: { icon: React.ReactNode, title: string, description: string }) {
  return (
    <div className="p-6 rounded-3xl bg-white/5 border border-white/10 backdrop-blur-xl hover:bg-white/10 transition-colors">
      <div className="w-12 h-12 bg-white/5 border border-white/10 rounded-2xl flex items-center justify-center mb-4">
         {icon}
      </div>
      <h3 className="text-lg font-semibold text-white mb-2">{title}</h3>
      <p className="text-gray-400 text-sm leading-relaxed">{description}</p>
    </div>
  );
}
