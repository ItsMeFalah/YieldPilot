import React from 'react';
import { vaultContractCode } from '../lib/contractCode';
import { ShieldAlert, BookOpen, Key, Layers, Coins, Rocket, ExternalLink, AlertTriangle } from 'lucide-react';
import { useDeployContract, useWaitForTransactionReceipt, useAccount, useSwitchChain } from 'wagmi';
import { base } from 'wagmi/chains';
import { VaultABI, VaultBytecode } from '../lib/DeployData';
import { USDC_ADDRESS } from '../lib/contracts';

export default function SmartContracts() {
  const { address, isConnected, chainId } = useAccount();
  const { switchChain } = useSwitchChain();
  const { deployContract, data: deployHash, isPending } = useDeployContract();
  
  const isWrongNetwork = isConnected && chainId !== base.id;

  const { isLoading: isWaitingDeploy, isSuccess: isDeploySuccess, data: receipt } = useWaitForTransactionReceipt({ 
    hash: deployHash 
  });

  const handleDeploy = () => {
    if (!address) return;
    if (isWrongNetwork) {
      switchChain({ chainId: base.id });
      return;
    }
    deployContract({
      abi: VaultABI,
      bytecode: VaultBytecode as `0x${string}`,
      args: [
        USDC_ADDRESS as `0x${string}`,
        address as `0x${string}`, // admin
        address as `0x${string}`, // keeper
        address as `0x${string}`, // treasury
      ],
    });
  };

  const isProcessing = isPending || isWaitingDeploy;

  return (
    <div className="max-w-7xl mx-auto grid grid-cols-1 xl:grid-cols-12 gap-8 pb-24">
      
      {/* Left Column: Architecture Explanation */}
      <div className="xl:col-span-5 space-y-6">
        <div className="space-y-4 mb-8">
          <h1 className="font-display text-3xl sm:text-4xl font-bold tracking-tight text-white flex items-center gap-3">
            <BookOpen className="text-blue-500" size={32} />
            Smart Contract <span className="bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-[#00C2FF]">Architecture</span>
          </h1>
          <p className="text-gray-400 font-sans leading-relaxed">
            The core protocol uses the Battle-Tested <strong className="text-gray-200">ERC-4626 Standard</strong>. Native vaults ensure complete interoperability with Base's DeFi ecosystem while maintaining ironclad security.
          </p>
        </div>

        {/* Deploy UI */}
        <div className="bg-blue-500/10 border border-blue-500/20 rounded-3xl p-6 relative overflow-hidden backdrop-blur-xl">
           <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/20 blur-[50px] rounded-full pointer-events-none"></div>
           <h3 className="text-white font-bold text-lg mb-2 flex items-center gap-2">
             <Rocket size={18} className="text-blue-400" /> Deploy to Base
           </h3>
           <p className="text-sm text-gray-300 mb-6">
             Deploy the YieldPilotVault directly from your browser. 
             You will be set as the initial admin and AI keeper.
           </p>

           <button 
             onClick={handleDeploy}
             disabled={(!isConnected) || isProcessing || (isDeploySuccess && !isWrongNetwork)}
             className="w-full py-3 bg-blue-600 hover:bg-blue-500 rounded-xl font-semibold text-white transition-all disabled:opacity-50 disabled:cursor-not-allowed flex justify-center items-center gap-2 mb-3"
           >
             {isWrongNetwork ? <><AlertTriangle size={18} /> Switch to Base</> : isPending ? 'Confirming in Wallet...' : isWaitingDeploy ? 'Deploying...' : isDeploySuccess ? 'Deployed Successfully!' : 'Deploy Contract'}
           </button>

           {!isConnected && (
             <p className="text-xs text-red-400 text-center">Connect your wallet to deploy</p>
           )}

           {isDeploySuccess && receipt?.contractAddress && (
             <div className="mt-4 p-3 bg-white/5 border border-white/10 rounded-xl font-mono text-xs text-center border-dashed block">
               <div className="text-gray-400 mb-1">Deployed Address:</div>
               <div className="text-green-400 mb-2 truncate max-w-full">{receipt.contractAddress}</div>
               
               <a href={`https://basescan.org/address/${receipt.contractAddress}`} target="_blank" rel="noreferrer" className="text-blue-400 hover:text-blue-300 flex items-center justify-center gap-1">
                 View on Basescan <ExternalLink size={12} />
               </a>
             </div>
           )}
        </div>

        <div className="space-y-4">
          <ArchitectureCard 
            icon={<Layers className="text-blue-400" size={20} />}
            title="ERC-4626 Standard"
            desc="Users deposit USDC and receive yield-bearing ypUSDC shares. The standard natively handles deposits, withdrawals, and exchange rate accounting."
          />
          <ArchitectureCard 
            icon={<ShieldAlert className="text-red-400" size={20} />}
            title="Emergency Circuit Breakers"
            desc="Implements OpenZeppelin's Pausable. The EMERGENCY_ADMIN_ROLE can halt deposits and rebalances instantly. Crucially, withdrawals remain unlocked to guarantee users can always exit."
          />
          <ArchitectureCard 
            icon={<Key className="text-yellow-400" size={20} />}
            title="RBAC Ownership Model"
            desc="No single super-owner. Defaults to AccessControl with specific roles: EMERGENCY_ADMIN (Gnosis Multisig) and AI_KEEPER_ROLE (Serverless relayer like Gelato)."
          />
          <ArchitectureCard 
            icon={<Coins className="text-emerald-400" size={20} />}
            title="High-Water Mark Auditing"
            desc="The performance fee logic triggers via harvest(). It records a High-Water Mark to ensure fees are only taken on new all-time-high profits, preventing double-charging during volatility."
          />
        </div>
      </div>

      {/* Right Column: Code Viewer */}
      <div className="xl:col-span-7">
        <div className="bg-white/5 border border-white/10 backdrop-blur-xl rounded-3xl overflow-hidden flex flex-col h-full shadow-2xl">
          {/* Mac-like Header */}
          <div className="bg-black/40 px-4 py-3 border-b border-white/5 flex items-center gap-3">
            <div className="flex gap-1.5">
              <div className="w-3 h-3 rounded-full bg-red-500/80"></div>
              <div className="w-3 h-3 rounded-full bg-yellow-500/80"></div>
              <div className="w-3 h-3 rounded-full bg-green-500/80"></div>
            </div>
            <span className="text-xs font-mono text-gray-400 ml-2 shadow-sm font-medium">YieldPilotVault.sol</span>
            <div className="ml-auto px-2 py-0.5 bg-blue-500/20 text-blue-400 text-[10px] uppercase font-bold rounded tracking-wider border border-blue-500/30">
              Solidity 0.8.24
            </div>
          </div>
          
          <div className="p-4 sm:p-6 overflow-auto text-sm flex-1 custom-scrollbar">
            <pre className="font-mono leading-relaxed">
              <code className="text-gray-300">
                {vaultContractCode.split('\n').map((line, i) => {
                  // Basic regex-free coloring for quick dev display
                  let colorClass = "text-gray-300";
                  if (line.trim().startsWith('//')) colorClass = "text-gray-500";
                  if (line.includes('pragma solidity') || line.includes('import')) colorClass = "text-[#00C2FF]";
                  if (line.trim().startsWith('contract') || line.includes('function ')) colorClass = "text-blue-400 font-semibold";
                  if (line.includes('require(') || line.includes('if (')) colorClass = "text-purple-400";
                  if (line.includes('event ')) colorClass = "text-emerald-400";

                  return (
                    <div key={i} className="table-row">
                      <span className="table-cell pr-4 text-gray-700 select-none text-right w-8">{i + 1}</span>
                      <span className={`table-cell ${colorClass}`}>{line}</span>
                    </div>
                  );
                })}
              </code>
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
}

function ArchitectureCard({ icon, title, desc }: { icon: React.ReactNode, title: string, desc: string }) {
  return (
    <div className="p-5 rounded-2xl bg-white/5 border border-white/5 flex gap-4 hover:bg-white/10 transition-colors">
      <div className="mt-1">{icon}</div>
      <div>
        <h3 className="text-white font-semibold mb-1">{title}</h3>
        <p className="text-sm text-gray-400 leading-relaxed">{desc}</p>
      </div>
    </div>
  );
}
