import React, { useState, useEffect } from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { ArrowDownLeft, ArrowUpRight, Cpu, Activity, ShieldCheck, Zap } from 'lucide-react';
import { cn } from '../lib/utils';

const mockChartData = [
  { day: 'Mon', apy: 6.2, yield: 12.5 },
  { day: 'Tue', apy: 6.4, yield: 15.2 },
  { day: 'Wed', apy: 7.1, yield: 19.8 },
  { day: 'Thu', apy: 6.8, yield: 24.1 },
  { day: 'Fri', apy: 8.5, yield: 29.5 },
  { day: 'Sat', apy: 8.1, yield: 34.2 },
  { day: 'Sun', apy: 8.9, yield: 41.0 },
];

const mockLogs = [
  { time: '10:42 AM', action: 'Moved 40% to Moonwell', reason: 'Supply APY spike to 8.5%', type: 'rebalance' },
  { time: '09:15 AM', action: 'Risk Scan Complete', reason: 'Aave V3 Utilization normal (62%)', type: 'scan' },
  { time: '08:00 AM', action: 'Compounded Yield', reason: 'Harvested $24.50 USDC from Morpho', type: 'compound' },
];

export default function VaultDashboard() {
  const [balance, setBalance] = useState<number>(0);
  const [amount, setAmount] = useState<string>('');
  const [activeTab, setActiveTab] = useState<'deposit' | 'withdraw'>('deposit');
  const [isProcessing, setIsProcessing] = useState(false);

  const handleTransaction = () => {
    if (!amount || isNaN(Number(amount))) return;
    setIsProcessing(true);
    setTimeout(() => {
      if (activeTab === 'deposit') {
        setBalance(prev => prev + Number(amount));
      } else {
        setBalance(prev => Math.max(0, prev - Number(amount)));
      }
      setAmount('');
      setIsProcessing(false);
    }, 1500);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
      
      {/* Left Column: Interactions & Stats */}
      <div className="lg:col-span-1 space-y-6">
        
        {/* Main Vault Card */}
        <div className="bg-white/5 border border-white/10 backdrop-blur-xl rounded-3xl p-6 relative overflow-hidden">
          {/* Subtle gradient overlay */}
          <div className="absolute top-0 right-0 -mr-16 -mt-16 w-48 h-48 bg-[#0052FF]/10 blur-3xl rounded-full pointer-events-none"></div>
          
          <div className="flex justify-between items-center mb-6">
             <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center">
                   <div className="w-3 h-3 bg-white rounded-full"></div>
                </div>
                <span className="font-display font-semibold text-white">USDC <span className="text-gray-500 font-normal border border-gray-800 px-1.5 py-0.5 rounded text-xs ml-1">Base</span></span>
             </div>
             <div className="text-right">
                <div className="text-xs text-gray-400 uppercase tracking-wider font-mono">Real-time APY</div>
                <div className="text-blue-400 font-mono font-bold text-lg">8.90%</div>
             </div>
          </div>

          <div className="space-y-1 mb-8">
             <div className="text-sm tracking-tight text-gray-400">Your Deposited Balance</div>
             <div className="font-mono text-4xl text-white font-medium flex items-baseline">
                <span className="text-gray-500 mr-1">$</span>
                {balance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
             </div>
          </div>

          {/* Action Tabs */}
          <div className="flex bg-white/5 p-1 rounded-xl mb-4 border border-white/10">
            <button 
              onClick={() => setActiveTab('deposit')}
              className={cn("flex-1 py-2 text-sm font-semibold rounded-lg transition-all", activeTab === 'deposit' ? 'bg-white/10 text-white shadow-sm border border-white/10' : 'text-gray-500 hover:text-white hover:bg-white/5')}
            >
              Deposit
            </button>
            <button 
              onClick={() => setActiveTab('withdraw')}
              className={cn("flex-1 py-2 text-sm font-semibold rounded-lg transition-all", activeTab === 'withdraw' ? 'bg-white/10 text-white shadow-sm border border-white/10' : 'text-gray-500 hover:text-white hover:bg-white/5')}
            >
              Withdraw
            </button>
          </div>

          <div className="space-y-4">
             <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 font-mono">$</span>
                <input 
                  type="number" 
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="0.00"
                  className="w-full bg-white/5 border border-white/10 rounded-xl py-3 pl-8 pr-16 text-white font-mono placeholder:text-gray-500 focus:outline-none focus:border-[#0052FF]/50 transition-colors"
                />
                <button className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-blue-400 hover:text-blue-300 font-medium px-2 py-1 bg-white/10 rounded border border-white/5">
                   MAX
                </button>
             </div>
             
             <button 
                onClick={handleTransaction}
                disabled={isProcessing || !amount}
                className="w-full py-4 bg-gradient-to-r from-[#0052FF] to-[#0085FF] rounded-2xl font-bold text-lg shadow-xl shadow-blue-500/20 hover:scale-[1.02] active:scale-95 transition-transform disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100 flex items-center justify-center gap-2 text-white border-0"
              >
                {isProcessing ? 'Processing Transaction...' : activeTab === 'deposit' ? 'Deposit to Vault' : 'Withdraw Funds'}
              </button>
          </div>
        </div>

        {/* Protocol Distribution */}
        <div className="bg-white/5 border border-white/10 backdrop-blur-xl rounded-3xl p-6">
           <h3 className="text-sm font-medium text-gray-400 mb-4 flex items-center gap-2">
             <ShieldCheck size={16} className="text-green-400" /> Current Allocation
           </h3>
           <div className="space-y-3">
              <div className="flex items-center justify-between">
                 <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-purple-500"></div>
                    <span className="text-sm text-gray-300">Moonwell</span>
                 </div>
                 <span className="text-sm font-mono text-white">40%</span>
              </div>
              <div className="flex items-center justify-between">
                 <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-blue-400"></div>
                    <span className="text-sm text-gray-300">Aave V3</span>
                 </div>
                 <span className="text-sm font-mono text-white">35%</span>
              </div>
              <div className="flex items-center justify-between">
                 <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-emerald-500"></div>
                    <span className="text-sm text-gray-300">Morpho</span>
                 </div>
                 <span className="text-sm font-mono text-white">25%</span>
              </div>
           </div>
        </div>

      </div>

      {/* Right Column: Charts & AI Log */}
      <div className="lg:col-span-2 space-y-6">
         
         {/* Performance Chart */}
         <div className="bg-white/5 border border-white/10 backdrop-blur-xl rounded-3xl p-6 h-[400px] flex flex-col">
            <div className="flex justify-between items-start mb-6">
               <div>
                  <h2 className="text-xl font-display font-semibold text-white">Cumulative Vault Yield</h2>
                  <p className="text-sm text-gray-400 mt-1">Historically simulated past 7 days based on AI routing.</p>
               </div>
               <div className="bg-green-500/10 text-green-400 border border-green-500/20 px-3 py-1 rounded-full text-xs font-mono flex items-center gap-2">
                  <Activity size={14} /> Model Active
               </div>
            </div>
            
            <div className="flex-1 w-full relative">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={mockChartData} margin={{ top: 10, right: 0, left: 0, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorYield" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#0052FF" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#0052FF" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{fill: '#6b7280', fontSize: 12}} dy={10} />
                  <YAxis hide domain={['dataMin - 10', 'auto']} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: 'rgba(255,255,255,0.05)', borderColor: 'rgba(255,255,255,0.1)', color: '#fff', borderRadius: '1rem', backdropFilter: 'blur(16px)' }}
                    itemStyle={{ color: '#00C2FF', fontFamily: 'monospace' }}
                  />
                  <Area type="monotone" dataKey="yield" stroke="#0052FF" strokeWidth={3} fillOpacity={1} fill="url(#colorYield)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
         </div>

         {/* AI Strategy Log */}
         <div className="bg-white/5 border border-white/10 backdrop-blur-xl rounded-3xl p-6">
            <h3 className="text-sm font-semibold text-gray-400 flex items-center gap-2 mb-4 border-b border-white/10 pb-4">
              <Cpu size={16} className="text-[#0052FF]" /> AI Quant Engine Feed
            </h3>
            
            <div className="space-y-4">
               {mockLogs.map((log, i) => (
                  <div key={i} className="flex gap-4 p-4 rounded-2xl bg-white/5 hover:bg-white/10 transition-colors border border-white/5 hover:border-white/10">
                     <div className="mt-1">
                        {log.type === 'rebalance' ? <ArrowUpRight size={18} className="text-blue-400" /> : 
                         log.type === 'scan' ? <Activity size={18} className="text-gray-400" /> : 
                         <Zap size={18} className="text-yellow-400" />}
                     </div>
                     <div className="flex-1">
                        <div className="flex items-center justify-between mb-1">
                           <span className="text-sm font-medium text-gray-200">{log.action}</span>
                           <span className="text-xs text-gray-500 font-mono">{log.time}</span>
                        </div>
                        <p className="text-xs text-gray-400">{log.reason}</p>
                     </div>
                  </div>
               ))}
               <div className="pt-2 text-center">
                  <span className="text-xs text-blue-500/70 hover:text-blue-400 cursor-pointer transition-colors font-mono uppercase tracking-widest">
                     View Complete On-Chain Log →
                  </span>
               </div>
            </div>
         </div>

      </div>

    </div>
  );
}
