import React, { useState } from 'react';
import { useAccount, useConnect, useDisconnect, useBalance, useSwitchChain } from 'wagmi';
import { base } from 'wagmi/chains';
import { Wallet, LogOut, ChevronDown, CheckCircle2, AlertTriangle } from 'lucide-react';
import { cn } from '../lib/utils';
import { formatEther } from 'viem';

interface ConnectButtonProps {
  className?: string;
  showBalance?: boolean;
}

export default function ConnectButton({ className, showBalance = false }: ConnectButtonProps) {
  const { address, isConnected, chainId } = useAccount();
  const { connectors, connect } = useConnect();
  const { disconnect } = useDisconnect();
  const { switchChain } = useSwitchChain();
  const [isOpen, setIsOpen] = useState(false);
  const { data: balanceData } = useBalance({
    address,
  });

  const isWrongNetwork = isConnected && chainId !== base.id;

  const handleConnect = (connector: any) => {
    connect({ connector, chainId: base.id });
    setIsOpen(false);
  };

  const formatAddress = (addr?: string) => {
    if (!addr) return '';
    return `${addr.slice(0, 6)}...${addr.slice(-4)}`;
  };

  if (isConnected && address) {
    if (isWrongNetwork) {
      return (
        <button 
          onClick={() => switchChain({ chainId: base.id })}
          className={cn(
            "flex items-center gap-2 px-4 py-2 sm:px-5 sm:py-2.5 bg-red-500/10 hover:bg-red-500/20 border border-red-500/30 text-red-400 rounded-full text-sm font-semibold transition-all backdrop-blur-md whitespace-nowrap",
            className
          )}
        >
          <AlertTriangle size={16} />
          Switch to Base
        </button>
      );
    }

    return (
      <div className="relative">
        <button 
          onClick={() => setIsOpen(!isOpen)}
          className={cn(
            "flex items-center gap-2 px-4 py-2 sm:px-5 sm:py-2.5 bg-blue-500/10 hover:bg-blue-500/20 border border-blue-500/30 text-blue-400 rounded-full text-sm font-semibold transition-all backdrop-blur-md whitespace-nowrap",
            className
          )}
        >
          <div className="w-2 h-2 rounded-full bg-green-400"></div>
          {formatAddress(address)}
          <ChevronDown size={14} className={cn("transition-transform", isOpen && "rotate-180")} />
        </button>

        {isOpen && (
          <div className="absolute right-0 mt-2 w-56 bg-[#0f172a] border border-white/10 rounded-2xl shadow-xl shadow-black/50 overflow-hidden z-50">
            <div className="p-3 border-b border-white/10">
               <div className="text-xs text-gray-400 uppercase tracking-wider font-semibold mb-1">Connected Wallet</div>
               <div className="text-sm text-white font-mono">{formatAddress(address)}</div>
               {showBalance && balanceData && (
                 <div className="text-sm font-semibold text-[#00C2FF] mt-1 pr-1">
                   {Number(formatEther(balanceData.value)).toFixed(4)} {balanceData.symbol}
                 </div>
               )}
            </div>
            <button 
              onClick={() => { disconnect(); setIsOpen(false); }}
              className="w-full flex items-center justify-between p-3 text-sm text-red-400 hover:bg-white/5 transition-colors text-left font-medium"
            >
              Disconnect <LogOut size={16} />
            </button>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="relative">
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className={cn(
          "flex items-center gap-2 px-4 py-2 sm:px-6 sm:py-2.5 bg-gradient-to-r from-[#0052FF] to-[#0085FF] hover:scale-105 active:scale-95 border border-[#0052FF]/50 rounded-full text-sm font-semibold transition-all backdrop-blur-md shadow-lg shadow-blue-500/20 text-white whitespace-nowrap",
          className
        )}
      >
        <Wallet size={16} />
        Connect Wallet
      </button>

      {isOpen && (
        <div className="absolute right-0 mt-2 w-64 bg-[#0f172a]/95 backdrop-blur-xl border border-white/10 rounded-2xl shadow-xl shadow-black/50 overflow-hidden z-50 animate-in fade-in zoom-in-95 duration-200">
           <div className="p-3 border-b border-white/10">
               <div className="text-xs text-gray-400 uppercase tracking-wider font-semibold">Select Provider</div>
           </div>
           <div className="p-2 flex flex-col gap-1">
              {connectors.map((connector) => (
                <button
                  key={connector.uid}
                  onClick={() => handleConnect(connector)}
                  className="w-full flex items-center gap-3 p-3 text-sm text-white hover:bg-white/10 rounded-xl transition-colors text-left font-medium"
                >
                  <div className="w-8 h-8 rounded-lg bg-white/10 flex items-center justify-center">
                     <Wallet className="text-gray-400" size={16} />
                  </div>
                  {connector.name}
                </button>
              ))}
           </div>
        </div>
      )}
    </div>
  );
}
