import React, { useState } from 'react';
import AIEngine from './AIEngine';
import SmartContracts from './SmartContracts';
import { cn } from '../lib/utils';
import { ShieldAlert, BookOpen, BrainCircuit, Activity } from 'lucide-react';

export default function TransparencyPage() {
  const [tab, setTab] = useState<'engine' | 'contracts'>('engine');

  return (
    <div className="max-w-7xl mx-auto space-y-8">
      
      {/* Header */}
      <div className="text-center max-w-2xl mx-auto mb-12">
         <h1 className="font-display text-4xl sm:text-5xl font-bold tracking-tight text-white mb-4">
            Total <span className="bg-clip-text text-transparent bg-gradient-to-r from-[#0052FF] to-[#00C2FF]">Transparency</span>
         </h1>
         <p className="text-lg text-gray-400 font-sans">
            We believe DeFi should be a glasshouse. Inspect our AI Quant Logic, verify our Smart Contracts, and audit our rebalancing history.
         </p>
      </div>

      {/* Sub-Navigation Tabs */}
      <div className="flex justify-center mb-8">
         <div className="flex items-center space-x-2 bg-white/5 p-1.5 rounded-2xl border border-white/10 backdrop-blur-md">
            <button
               onClick={() => setTab('engine')}
               className={cn(
               "flex items-center gap-2 px-6 py-3 rounded-xl text-sm font-bold transition-all duration-200",
               tab === 'engine' 
                  ? "bg-white/10 text-white shadow-md border border-white/10" 
                  : "text-gray-400 hover:text-white hover:bg-white/5"
               )}
            >
               <BrainCircuit size={18} />
               <span>Quant Logic Engine</span>
            </button>
            <button
               onClick={() => setTab('contracts')}
               className={cn(
               "flex items-center gap-2 px-6 py-3 rounded-xl text-sm font-bold transition-all duration-200",
               tab === 'contracts' 
                  ? "bg-white/10 text-white shadow-md border border-white/10" 
                  : "text-gray-400 hover:text-white hover:bg-white/5"
               )}
            >
               <BookOpen size={18} />
               <span>Smart Contracts</span>
            </button>
         </div>
      </div>

      {/* Content Rendering */}
      <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
         {tab === 'engine' ? <AIEngine /> : <SmartContracts />}
      </div>

    </div>
  );
}
